#include <bits/stdc++.h>
using namespace std;

int main() {
    int N, Q;
    scanf(" %d %d", &N, &Q);

    for(int i = 0; i < Q; i++) {
        int query;
        scanf(" %d", &query);
        
        // domjudge
    }
}
